# Tweepy is a Python library for accessing the Twitter API
import tweepy
# Flask is a web framework for creating web apps in Python 3
from flask import Flask
from flask import request       # This object is used to receive user input

# Tweepy Authentication
# Using app keys and tokens from my developer app
auth = tweepy.OAuthHandler("I8du75AluHGuyepB7O14ZNJyu", "Jg0IN5JiAOt684Ust0rQ5nNhpJYUUoRy1iRfbCVYEjTYX0rQ7i")
auth.set_access_token("371302729-2qF49kYJRElsDGxXUH3mAZlJCRiuDEuNIeHnPrEY", "0Z5bvtg5ogPbfNrRyUDiBpfLZo8RwuNRvucXk9Ip0tToc")

api = tweepy.API(auth)

# Create Flask app 
app = Flask(__name__)

# Python decorator that Flask uses to connect URL endpoints with code contained in functions
# Argument "/" defines the URL's path component (root path ("/"))
@app.route("/")

# Function that runs when the base URL of this app is typed into the browser
# Return value determines what a user sees when they load the page
def index():
    
    tweet = request.args.get("tweet", "")
    filename = request.args.get("filename", "")
    
    
    # If tweet is given, run following functions
    # else leave display blank
    if tweet:
        status = text_from(tweet)
        user = username_from(tweet)
        likes = likes_from(tweet)
        retweets = retweets_from(tweet)
    else:
        status = ""
        user = ""
        likes = ""
        retweets = ""
        
    if filename:
        fileName = print_filename(filename)
        fileText = read_filetext(filename)
        fileTweetInfo = read_tweet_file(filename)
    else:
        fileName = ""
        fileText = ""
        fileTweetInfo = ""
  
    # HTML Formatting
    return (
        """<form action="" method="get">
                <ul style ='padding: 5px; font-size:25px;background-color:#1DA1F2; color:white;letter-spacing: 1.5px;border: 2px inset graytext;'>
                Please enter a Tweet URL:<input style='margin-left: 1rem; ' type="text" name="tweet"><input type="submit" value="Submit"></ul> 
            </form>"""
        + "<li style ='padding: 5px; font-size:20px;background-color:lightblue; color:black;border: 2px inset graytext;'>Username: " 
        + user      + """</li><br>""" 
        + "<li style ='padding: 5px; font-size:20px;background-color:lightblue; color:black; border: 2px inset graytext;'>Tweet Text: "
        + status    + """</li><br>""" 
        + "<li style ='padding: 5px; font-size:20px;background-color:lightblue; color:black;border: 2px inset graytext;'>Current Likes: "
        + likes     + """</li><br>"""
        + "<li style ='padding: 5px; font-size:20px;background-color:lightblue; color:black;border: 2px inset graytext;'>Current Retweets: "
        + retweets 
        + """</li><br><form action="" method="get">
                <ul style ='padding: 5px; font-size:25px;background-color:#1DA1F2; color:white;letter-spacing: 1.5px;border: 2px inset graytext;'>
                Please choose a text file with Tweet URLS: <input type="file" name="filename">
                <input type="submit" value="Submit"></ul>
             </form>"""
        + "<li style ='padding: 5px; font-size:20px;background-color:lightblue; color:black;border: 2px inset graytext;'>File Name: <br>"
        + fileName  + "</li><br><li style ='padding: 5px; font-size:20px;background-color:lightblue; color:black;border: 2px inset graytext;'>File Text: <br>"
        + fileText  + "</li><br><li style ='padding: 5px; font-size:20px;background-color:lightblue; color:black;border: 2px inset graytext;'>Tweet Info: <br>"
        + fileTweetInfo + "</li>"
    )

# Return the name of the file that the user selected
def print_filename(filename):
    return str(filename)

# Returns the text written in the file
def read_filetext(filename):
    f = open(str(filename), "r")
    fText = f.read()
    return fText
    
def read_tweet_file(filename):
    with open(str(filename)) as userfile:
        for line in userfile:
            likeslist = []
            currentID = line.rsplit('/', 1)[-1]
            status = api.get_status(currentID)
            user = status.author
            likes = status.favorite_count
            retweets = status.retweet_count
            likeslist.append(likes)
            
            return('Username: ' + str(user.screen_name) + """<br>""" +'Tweet Text: ' + str(status.text) +
                    """<br>""" + 'Current Likes: ' + str(likes) + """<br>""" + 'Current Retweets: ' + str(retweets) + """<br>""")
     
            

# Returns the username of the person who wrote the tweet
def username_from(tweet):
    ID = tweet.rsplit('/', 1)[-1]       # Takes last part of url parameter (tweet ID)
    status = api.get_status(ID)
    user = status.author
    return str(user.screen_name)
  
# Returns the text content of the tweet
def text_from(tweet):
    ID = tweet.rsplit('/', 1)[-1]
    status = api.get_status(ID)
    return str(status.text)

# Returns the number of likes that the tweet has
def likes_from(tweet):
    ID = tweet.rsplit('/', 1)[-1]
    status = api.get_status(ID)
    likes = status.favorite_count
    return str(likes)

# Returns the number of retweets that the tweet has
def retweets_from(tweet):
    ID = tweet.rsplit('/', 1)[-1]
    status = api.get_status(ID)
    retweets = status.retweet_count
    return str(retweets)

# Local connection 
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080, debug=True)
    
    
