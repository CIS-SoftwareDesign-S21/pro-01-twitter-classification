# Tweepy is a Python library for accessing the Twitter API
import tweepy
# Flask is a web framework for creating web apps in Python 3
from flask import Flask
from flask import request       # This object is used to receive user input

# Using app keys and tokens from my developer app
auth = tweepy.OAuthHandler("I8du75AluHGuyepB7O14ZNJyu", "Jg0IN5JiAOt684Ust0rQ5nNhpJYUUoRy1iRfbCVYEjTYX0rQ7i")
auth.set_access_token("371302729-2qF49kYJRElsDGxXUH3mAZlJCRiuDEuNIeHnPrEY", "0Z5bvtg5ogPbfNrRyUDiBpfLZo8RwuNRvucXk9Ip0tToc")

api = tweepy.API(auth)

# Tweepy Authentication (above)

# Create Flask app 
app = Flask(__name__)

# Python decorator that Flask uses to connect URL endpoints with code contained in functions
# Argument "/" defines the URL's path component (root path ("/"))
@app.route("/")

# Function that runs when the base URL of this app is typed into the browser
# Return value determines what a user sees when they load the page
def index():
   
    tweet = request.args.get("tweet", "")
    
    if tweet:
        status = text_from(tweet)
        user = username_from(tweet)
        likes = likes_from(tweet)
        retweets = retweets_from(tweet)
    else:
        status = ""
        user = ""
        likes = ""
        retweets = ""
  
    return (
        """<form action="" method="get">
                Please enter a Tweet URL: <input type="text" name="tweet">
                <input type="submit" value="Submit">
            </form>"""
        + "Username: " 
        + user      + """<br>""" 
        + "Tweet Text: "
        + status    + """<br>""" 
        + "Current Likes: "
        + likes     + """<br>"""
        + "Current Retweets: "
        + retweets
        
    )

def username_from(tweet):
    """Prints username from tweet."""
    # Takes last part of url parameter (tweet ID)
    ID = tweet.rsplit('/', 1)[-1]
    status = api.get_status(ID)
    user = status.author
    return str(user.screen_name)

def text_from(tweet):
    """Prints text from tweet."""
    # Takes last part of url parameter (tweet ID)
    ID = tweet.rsplit('/', 1)[-1]
    status = api.get_status(ID)
    return str(status.text)

def likes_from(tweet):
    ID = tweet.rsplit('/', 1)[-1]
    status = api.get_status(ID)
    likes = status.favorite_count
    return str(likes)

def retweets_from(tweet):
    ID = tweet.rsplit('/', 1)[-1]
    status = api.get_status(ID)
    retweets = status.retweet_count
    return str(retweets)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080, debug=True)
    
    
